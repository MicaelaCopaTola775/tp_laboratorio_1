#ifndef ArrayEmployees_h_incluido
#define ArrayEmployees_h_incluido
typedef struct
{
    int id;
    char name[51];
    char lastName[51];
    float salary;
    int sector;
    int isEmpty;
}eEmployee;

int menu();
void initEmployees(eEmployee lista[], int len);
int buscarLibre(eEmployee lista[], int len);
void addEmployee(eEmployee lista[], int len);
int findEmployeeId(eEmployee lista[], int len, int id);
void mostrarEmpleado(eEmployee lista, int len);
void printEmployees(eEmployee lista[], int len);
void removeEmployee(eEmployee lista[], int len, int isEmpty);
void modificarEmpleado(eEmployee lista[], int len);
void sortEmployees(eEmployee lista[], int len);
void promedioEmpleados(eEmployee lista[],int len);

#endif
