#include <stdio.h>
#include <stdlib.h>
#include "ArrayEmployees.h"
#include <conio.h>
#include <ctype.h>
#define TAM_EMPLOYEE 3

int main()
{
    char seguir = 's';
    char confirmar;

    eEmployee list[TAM_EMPLOYEE];
    initEmployees(list, TAM_EMPLOYEE);

    do
    {
        switch(menu())
        {
        case 1:
            addEmployee(list,TAM_EMPLOYEE);
            system("pause");
            break;
        case 2:
            modificarEmpleado(list,TAM_EMPLOYEE);
            system("pause");
            break;
        case 3:
            removeEmployee(list,TAM_EMPLOYEE,1);
            system("pause");
            break;
        case 4:
            sortEmployees(list,TAM_EMPLOYEE);
            promedioEmpleados(list,TAM_EMPLOYEE);
            system("pause");
            break;
        case 5:
            printf("\nRealmente desea salir [s/n]?: ");
            fflush(stdin);
            confirmar = getche();

            if(tolower(confirmar) == 's')
            {
                seguir = 'n';
            }
            break;
        default:
            printf("\nError, opcion invalida!!\n");
            system("break");
            break;
        }
    }while(seguir == 's');

    return 0;
}

