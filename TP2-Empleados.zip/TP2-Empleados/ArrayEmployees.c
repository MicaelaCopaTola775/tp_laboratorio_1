#include <stdio.h>
#include <stdlib.h>
#include "ArrayEmployees.h"
#include <conio.h>
#include <string.h>

/** \brief Mostrara un menu con opciones donde el usuario debera elejir una
 *
 * \param
 * \param
 * \return Retorna la opcion que el usuario eligio
 *
 */

int menu()
{
    int opcion;

    system("cls");
    printf("********MENU********\n\n");
    printf("1-Alta de Empleados\n");
    printf("2-Modificar empleados\n");
    printf("3-Baja de empleados\n");
    printf("4-Informar empleados\n");
    printf("5-Salir\n\n");
    printf("Ingrese una opcion: ");
    scanf("%d",&opcion);

    return opcion;
}
/** \brief Se marcan todas las posiciones del array como libres
 *          colocando en cada elemento el campo Ocupado en TRUE
 *
 * \param array de eLista
 * \param Tama�o del array
 * \return No retorna nada
 *
 */
void initEmployees(eEmployee lista[], int len)
{
    int i;
    for( i=0; i < len; i++)
    {
        lista[i].isEmpty = 0;
    }
}
/** \brief Busca un lugar libre de la estructura eLista
 *
 * \param array de eLista
 * \param tama�o del array
 * \return retorna el indice el cual esta libre
 *
 */

int buscarLibre(eEmployee lista[], int len)
{

    int indice = -1;
    int i;
     for(i=0; i < len; i++)
    {
        if(lista[i].isEmpty == 0){
            indice = i;
            break;
        }
    }

    return indice;
}
/** \brief permite al usuario dar de alta un empleado ingresando todos sus datos
 *
 * \param array de la estructura
 * \param tama�o del array
 * \return no retorna nada
 *
 */
void addEmployee(eEmployee lista[], int len)
{

    int indice;

    indice = buscarLibre(lista, len);

    if( indice == -1)
    {
        printf("\nNo hay lugar en el sistema\n");
    }else{
            lista[indice].id=indice+1;

            printf("Su id sera: %d \n", lista[indice].id);

            printf("\nIngrese nombre: ");
            fflush(stdin);
            gets(lista[indice].name);

            printf("\nIngrese apellido: ");
            fflush(stdin);
            gets(lista[indice].lastName);

            printf("\nIngrese sueldo: ");
            scanf("%f", &lista[indice].salary);

            printf("\nIngrese sector: ");
            scanf("%d", &lista[indice].sector);

            lista[indice].isEmpty = 1;

            printf("\nAlta empleado completado con exito!\n\n");

        }

}
/** \brief Busca el empleado solicitado por el usuario segun su id
 *
 * \param array de la estructura eLista
 * \param tama�o del array
 * \param id a ingresar por el usuario
 * \return indice del empleado solicitado
 *
 */
int findEmployeeId(eEmployee lista[], int len, int id)
{

    int indice = -1;
    int i;

    for(i=0; i < len; i++)
    {
        if(lista[i].isEmpty == 1 && lista[i].id == id)
        {
            indice = i;
            break;
        }
    }

    return indice;
}
/** \brief muestra todos los campos del empleado solicitado
 *
 * \param array de la estructura eLista
 * \param  tama�o del array
 * \return No retorna nada
 *
 */
void mostrarEmpleado(eEmployee lista, int len)
{

    printf("%d      %10s     %s    %.3f      %d \n", lista.id, lista.name, lista.lastName,lista.salary, lista.sector);

}
/** \brief muestra lista de todos los empleados dados de alta
 *
 * \param array de la estructura
 * \param tama�o del array
 * \return No retorna nada
 *
 */
void printEmployees(eEmployee lista[], int len)
{
    int contador = 0;
    int i;

    printf(" Id        Nombre    Apellido    Sueldo     Sector\n\n");

    for(i=0; i < len; i++)
    {
        if(lista[i].isEmpty == 1)
        {
            mostrarEmpleado(lista[i],len);
            contador++;
        }
    }

    if( contador == 0)
    {
        printf("\nNo hay empleados para mostrar\n");
    }
}
/** \brief permite al usuario borrar un empleado con todos sus datos
 *
 * \param array de la estructura
 * \param tama�o del array
 * \return no retorna nada
 *
 */
void removeEmployee(eEmployee lista[], int len, int isEmpty)
{
    int id;
    int indice;
    char opcion;

    printEmployees(lista,len);
    printf("\nIngrese el Id del empleado que desa dar de baja: ");
    scanf("%d",&id);
    indice=findEmployeeId(lista,len,id);
    if(lista[indice].id==id)
    {
        mostrarEmpleado(lista[indice],len);
        printf("\nDesea dar de baja a este empleado?: s/n");
        setbuf(stdin,NULL);
        scanf("%c",&opcion);
        if(opcion=='s')
        {
            lista[indice].isEmpty=0;
            printf("\nEmpleado dado de baja con exito!\n");
        }
        else
        {
            printf("\nNo pudo ser dado de baja!\n");
        }
    }
    else
    {
        printf("\nError! legajo inexistente!\n");
    }
}
/** \brief permite que el usuario modifique algun dato de un empleado
 *
 * \param array de la estructura
 * \param tama�o de array
 * \return no retorna nada
 *
 */
void modificarEmpleado(eEmployee lista[], int len)
{
    int id;
    int opcion;
    int indice;

    printEmployees(lista,len);
    printf("\nIngrese el Id del empleado a modificar: ");
    scanf("%d", &id);

    indice = findEmployeeId(lista,len,id);

    system("cls");
    printf("\nIngrese la opcion del dato a modificar:\n");
    printf("1-Nombre\n");
    printf("2-Apellido\n");
    printf("3-Sueldo\n");
    printf("4-Sector\n");
    scanf("%d", &opcion);

    if(indice != -1)
    {
            switch(opcion)
            {
            case 1:
                printf("\nIngrese nombre: ");
                fflush(stdin);
                gets(lista[indice].name);
                printf("El nombre nuevo es: %s", lista[indice].name);

                break;
            case 2:
                printf("\nIngrese apellido: ");
                fflush(stdin);
                gets(lista[indice].lastName);
                printf("El apellido nuevo es: %s", lista[indice].lastName);
                break;
            case 3:
                printf("\nIngrese sueldo: ");
                scanf("%f", &lista[indice].salary);
                printf("El sueldo nuevo es: %.3f", lista[indice].salary);
                break;
            case 4:
                printf("\nIngrese sector: ");
                scanf("%d", &lista[indice].sector);
                printf("El sector nuevo es: %d", lista[indice].sector);
                break;
            default:
                printf("Opcion invalida\n");
                break;
            }
    }else
    {
        printf("No se ha encontrado ese legajo");
    }
}
/** \brief ordena todos los empleados ingresados de forma ascendente
 *
 * \param array de la estructura
 * \param tama�o del array
 * \return no retorna nada
 *
 */
void sortEmployees(eEmployee lista[], int len)
{
    eEmployee auxiliar;

    for(int i=0; i<len-1; i++)
    {
        for(int j=i+1; j<len; j++)
        {
            if(strcmp(lista[i].lastName, lista[j].lastName)>0)
            {
                auxiliar=lista[i];
                lista[i]=lista[j];
                lista[j]=auxiliar;
            }
        }
    }

    printf("\nEmpleados ordenados: \n\n");

    for(int i=0; i<len; i++)
    {
        printf(" %d    %10s     %8s     %.2f    %d \n", lista[i].id,lista[i].lastName,lista[i].name,lista[i].salary, lista[i].sector);
    }
}
/** \brief permite sacar el total de todos los sueldos y dar al final el prmedio final
 *
 * \param array de la estructura
 * \param tama�o del array
 * \return
 *
 */

void promedioEmpleados(eEmployee lista[],int len)
{
    int i;
    int total;
    int promedio;

    for(i=0;i<len;i++)
    {
        total+=lista[i].salary;
        promedio=total/len;
    }

    printf("\nEl total de los sueldos es: %d  \n",total);
    printf("\nEL promdedio de todos los salarios es: %d  \n", promedio);
}
